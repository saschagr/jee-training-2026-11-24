/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package jms;

import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import javax.naming.InitialContext;

public class Sender {
	public static void main(String[] args) throws Exception {
		InitialContext initialContext = new InitialContext();
		ConnectionFactory factory = (ConnectionFactory) initialContext.lookup("jms/RemoteConnectionFactory");
		Destination ziel = (Destination) initialContext.lookup("jms/queue/Praxisbuch");

		try (Connection connection = factory.createConnection("app", "jboss");
				Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
				MessageProducer sender = session.createProducer(ziel)) {
			
			connection.start();

			TextMessage nachricht = session.createTextMessage();
			nachricht.setStringProperty("Bestellungstyp", "Internet");
			nachricht.setText("Ein EJB3-Buch bitte, sofort!");

			System.out.println("Sende Nachricht...");

			sender.send(nachricht);
			
			System.out.println("Nachricht gesendet");

		}
	}
}