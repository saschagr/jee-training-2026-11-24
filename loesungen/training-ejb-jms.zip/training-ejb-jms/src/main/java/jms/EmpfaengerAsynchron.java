/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package jms;

import java.time.LocalTime;

import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageListener;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import javax.naming.InitialContext;

public class EmpfaengerAsynchron implements MessageListener {
	public static void main(String[] args) throws Exception {
		InitialContext initialContext = new InitialContext();
		ConnectionFactory factory = (ConnectionFactory) initialContext.lookup("jms/RemoteConnectionFactory");
		Destination postfach = (Destination) initialContext.lookup("jms/queue/Praxisbuch");
		
		try (Connection connection = factory.createConnection("app", "jboss");
				Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);) {

			connection.start();


			MessageConsumer empfaenger = session.createConsumer(postfach, "Bestellungstyp = 'Internet'");
			empfaenger.setMessageListener(new EmpfaengerAsynchron());

			System.out.println("Warte auf Nachrichten... (Beenden mit CTRL-C)");
			Thread.sleep(9999999);
		}
	}

	@Override
	public void onMessage(Message nachricht) {
		try {
			System.out.println("Nachricht empfangen onMessage!");
			System.out.println(LocalTime.now() + " - " + ((TextMessage) nachricht).getText());
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}
}
