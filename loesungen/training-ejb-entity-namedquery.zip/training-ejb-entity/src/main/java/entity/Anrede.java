package entity;

public enum Anrede {
	
	SIE, FRAU, HERR, DU

}
