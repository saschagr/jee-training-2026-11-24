package entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Embeddable;

@Embeddable
public class Telefon implements Serializable {
	private String nummer;

	@Override
	public int hashCode() {
		return Objects.hash(nummer);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Telefon other = (Telefon) obj;
		return Objects.equals(nummer, other.nummer);
	}

	public String getNummer() {
		return nummer;
	}

	public void setNummer(String nummer) {
		this.nummer = nummer;
	}

	@Override
	public String toString() {
		return "Telefon [nummer=" + nummer + "]";
	}
	
	
}
