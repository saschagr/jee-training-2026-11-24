/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/ 
package entity;

import javax.naming.InitialContext;

public class KundenClient {
    public static void main(String[] args) throws Exception {
        InitialContext context = new InitialContext();
        
        KundenDAO dao = (KundenDAO) 
        		context.lookup("training-ejb-entity/KundenDAOBean!entity.KundenDAO");        
        
        int id = erzeugeKunde(dao, Anrede.FRAU, "Max", "Musterfrau");
        
        findeKunde(dao, id);
        
        aktualisiereKunde(dao, id, "Paula", "Musterfrau");
        
        findeKunde(dao, id);
        
        /***************/
        id = erzeugeKunde(dao, Anrede.HERR, "Sascha", "Groß");
        
        Adresse adresse = new Adresse();
        adresse.setStrasse("Schillerstraße");
        adresse.setHausnummer("14");
        adresse.setPlz("90409");
        adresse.setOrt("Nürnberg");
        dao.setzeAdresse(id, adresse);
        
        Telefon telefon = new Telefon();
        telefon.setNummer("+49 (0)911 376745-0");      
        dao.telefonnumerHinzufuegen(id, telefon);

        telefon = new Telefon();
        telefon.setNummer("+49 (0)911 376745-55");
        dao.telefonnumerHinzufuegen(id, telefon);
        
        findeKunde(dao, id);
        
        dao.telefonnumerEntfernen(id, telefon);
        
        findeKunde(dao, id);
        
        Ware ware = new Ware();
        ware.setName("Tee");
        dao.wareHinzufuegen(id, ware);

        ware = new Ware();
        ware.setName("Kaffee");
        dao.wareHinzufuegen(id, ware);

        findeKunde(dao, id);

        erzeugeKunde(dao, Anrede.HERR, "Fritz", "Groß");
        erzeugeKunde(dao, Anrede.HERR, "Fritz", "Klein");
        
        System.out.println("Kunden mit Vornamen Fritz \n" +
        		dao.sucheKundenMitVorname("Fritz")
        );
    }
    
    private static int erzeugeKunde(KundenDAO dao, Anrede anrede, String vorname, String nachname) {
    	return dao.erzeugeKunde(anrede, vorname, nachname);
    }
    
    private static void findeKunde(KundenDAO dao, int id) {
    	Kunde kunde = dao.findeKunde(id);
        if (kunde != null) {
            System.out.println(kunde.getVorname() + " " + kunde.getNachname() + " - "  + kunde.toString());
        } else {
            System.out.println("Nicht gefunden");
        }
    }
    
    private static void aktualisiereKunde(KundenDAO dao, int id, String vorname, String nachname) {
        Kunde kunde = dao.aktualisiereKunde(id, vorname, nachname);
        if (kunde == null) {
            System.out.println("Kein passender Kunde vorhanden");
        }
    }
    
    /*
        if (args.length > 0) {
            if (args[0].equals("erzeuge") && args.length == 3) {
                int kundenNr = dao.erzeugeKunde(args[1], args[2]);
                System.out.println(kundenNr);
                return;
            }
            else if (args[0].equals("finde") && args.length == 2) {
                Kunde kunde = dao.findeKunde(Integer.parseInt(args[1]));
                if (kunde != null)
                    System.out.println(kunde.getVorname() + " " + kunde.getNachname());
                else
                    System.out.println("Nicht gefunden");
                return;
            }
            else if (args[0].equals("aktualisiere") && args.length == 4) {
                Kunde kunde = dao.aktualisiereKunde(Integer.parseInt(args[1]), args[2], args[3]);
                if (kunde == null)
                    System.out.println("Kein passender Kunde vorhanden");
                return;
            }
        }
        System.out.println
            ("Aufruf: KundenClient\n" +
             "  erzeuge <Vorname> <Nachname>\n" +
             "  finde <ID>\n" +
             "  aktualisiere <ID> <Vorname> <Nachname>");
     */
}
