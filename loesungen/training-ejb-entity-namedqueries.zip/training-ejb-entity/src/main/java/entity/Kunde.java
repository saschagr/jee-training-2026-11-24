package entity;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.persistence.Version;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@NamedQuery(
		name = Kunde.QUERY_FINDE_KUNDE_MIT_VORNAME,
		query = "select k from Kunde k where k.vorname = :vorname")
@NamedQuery(
		name = Kunde.QUERY_FINDE_KUNDE_MIT_VORNAME_NACHNAME,
		query = "select k from Kunde k where k.vorname = :vorname and k.nachname = : nachname")
@NamedQuery(
		name = Kunde.QUERY_FINDE_KUNDE_MIT_PLZ,
		query = "select k from Kunde k where k.adresse.plz = :plz")
@NamedQuery(
		name = Kunde.QUERY_FINDE_EINEN_KUNDE_MIT_VORNAMEN,
		query = "select k from Kunde k where k.vorname = :vorname")

@Table(name = "Kunden")
@Entity(name = "Kunde")
public class Kunde implements Serializable {
	
	public static final String QUERY_FINDE_KUNDE_MIT_VORNAME 
								= "Kunde.findeKundeMitVorname";
	public static final String QUERY_FINDE_KUNDE_MIT_VORNAME_NACHNAME 
								= "Kunde.findeKundeMitVornameNachname";
	public static final String QUERY_FINDE_KUNDE_MIT_PLZ 
								= "Kunde.findeKundeMitPlz";
	public static final String QUERY_FINDE_EINEN_KUNDE_MIT_VORNAMEN 
								= "Kunde.findeEinenKundeMitVorname";
	
	public static final String PARAM_VORNAME = "vorname";
	public static final String PARAM_NACHNAME = "nachname";
	public static final String PARAM_PLZ = "plz";
	
	@Id
	@GeneratedValue
	private int id;
	

	@Enumerated(EnumType.STRING)
	@NotNull
	private Anrede anrede;
	
	@NotNull
	@Size(min = 2, max = 50)
	@Pattern(regexp = "^[A-Z].*")
	@Column(name = "vor_name", length = 50)
	private String vorname;

	@Basic(fetch = FetchType.EAGER)
	@Column(name = "nach_name", length = 255)
	private String nachname;
	
	@Transient
	private String alter;
	
	@Embedded
	@AttributeOverride(
			name = "hausnummer",
			column = @Column(name = "hausnummerEW")
	)
	@Valid
	private Adresse adresse;
	
	@Embedded
	@AttributeOverride(
			name = "hausnummer",
			column = @Column(name = "hausnummerZW")
	)
	@AttributeOverride(
			name = "strasse",
			column = @Column(name = "strasseZW")
	)
	@AttributeOverride(
			name = "plz",
			column = @Column(name = "plzZW")
	)
	@AttributeOverride(
			name = "ort",
			column = @Column(name = "ortZW")
	)
	private Adresse adresseZweitwohnung;
	
	@ElementCollection(fetch = FetchType.EAGER)
	private Set<Telefon> telefone;
	
	@Version
	private Long version;
	
	@OneToMany(cascade = {CascadeType.PERSIST}, fetch = FetchType.EAGER)
	@JoinColumn(name = "kunden_id")
	private List<Ware> waren;
	
	
	public Anrede getAnrede() {
		return anrede;
	}

	public void setAnrede(Anrede anrede) {
		this.anrede = anrede;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getAlter() {
		return alter;
	}

	public void setAlter(String alter) {
		this.alter = alter;
	}

	public Set<Telefon> getTelefone() {
		return telefone;
	}

	public void setTelefone(Set<Telefon> telefone) {
		this.telefone = telefone;
	}

	public int getId() {
		return id;
	}

	public Long getVersion() {
		return version;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public List<Ware> getWaren() {
		return waren;
	}

	public void setWaren(List<Ware> waren) {
		this.waren = waren;
	}

	@Override
	public String toString() {
		return "Kunde [id=" + id + ", anrede=" + anrede + ", vorname=" + vorname + ", nachname=" + nachname + ", alter="
				+ alter + ", adresse=" + adresse + ", adresseZweitwohnung=" + adresseZweitwohnung + ", telefone="
				+ telefone + ", version=" + version + ", waren=" + waren + "]";
	}

}
