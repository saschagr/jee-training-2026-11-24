package entity;

import java.util.List;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import jakarta.persistence.NonUniqueResultException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Stateless
public class KundenDAOBean implements KundenDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int erzeugeKunde(Anrede anrede, String vorname, String nachname) {
		Kunde kunde = new Kunde();
		kunde.setAnrede(anrede);
		kunde.setVorname(vorname);
		kunde.setNachname(nachname);
		
		entityManager.persist(kunde);
		
		return kunde.getId();
	}

	@Override
	public Kunde findeKunde(int id) {
		return entityManager.find(Kunde.class, id);
	}

	@Override
	public Kunde aktualisiereKunde(int id, String vorname, String nachname) {
		Kunde kunde = findeKunde(id);
		if (kunde != null) {
			kunde.setVorname(vorname);
			kunde.setNachname(nachname);
		}
		return kunde;
	}

	@Override
	public Kunde setzeAdresse(int kundenId, Adresse adresse) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.setAdresse(adresse);
		}
		return kunde;
	}

	@Override
	public Kunde telefonnumerHinzufuegen(int kundenId, Telefon telefon) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.getTelefone().add(telefon);
		}
		return kunde;
	}

	@Override
	public Kunde telefonnumerEntfernen(int kundenId, Telefon telefon) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.getTelefone().remove(telefon);
		}
		return kunde;
	}
	
	public Kunde wareHinzufuegen(int kundenId, Ware ware) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			//entityManager.persist(ware);
			kunde.getWaren().add(ware);
		}
		return kunde;
		
	}
	
	@Override
	public List<Kunde> sucheKundenMitVorname(String vorname) {
		TypedQuery<Kunde> query = 
				entityManager
				//.createQuery(
				//		"select k from Kunde k where k.vorname = :vorname",
				//		Kunde.class
				//);
				.createNamedQuery(Kunde.QUERY_FINDE_KUNDE_MIT_VORNAME, Kunde.class);
		query.setParameter(Kunde.PARAM_VORNAME, vorname);
		
		return query.getResultList();
	}
	
    public List<Kunde> sucheKundenMitVornameUndNachname(String vorname, String nachname) {
    	return
			entityManager
				.createNamedQuery(
						Kunde.QUERY_FINDE_KUNDE_MIT_VORNAME_NACHNAME, 
						Kunde.class)
				.setParameter(Kunde.PARAM_VORNAME, vorname)
				.setParameter(Kunde.PARAM_NACHNAME, nachname)
				.getResultList();
    }

    public List<Kunde> sucheKundenMitPlz(String plz) {
    	return
			entityManager
				.createNamedQuery(
						Kunde.QUERY_FINDE_KUNDE_MIT_PLZ, 
						Kunde.class)
				.setParameter(Kunde.PARAM_PLZ, plz)
				.getResultList();
    }

    public Kunde sucheEinenKundenVorname(String vorname) throws KeinenEindeutigenKundenGefundenException {
    	try {
    	return
			entityManager
				.createNamedQuery(
						Kunde.QUERY_FINDE_EINEN_KUNDE_MIT_VORNAMEN, 
						Kunde.class)
				.setParameter(Kunde.PARAM_VORNAME, vorname)
				.getSingleResult();
    	} catch(NonUniqueResultException | NoResultException e) {
    		throw new KeinenEindeutigenKundenGefundenException(
    				"Für " + vorname + " wurde kein eindeutiger Kunde gefunden. " 
					+ e.getMessage()
    				);
    	}
    }


}
