package entity;

public class KeinenEindeutigenKundenGefundenException extends Exception {
	
	public KeinenEindeutigenKundenGefundenException(String message) {
		super(message);
	}

}
