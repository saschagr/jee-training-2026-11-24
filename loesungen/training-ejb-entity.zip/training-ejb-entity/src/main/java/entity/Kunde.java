package entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import jakarta.persistence.Access;
import jakarta.persistence.AccessType;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
import jakarta.persistence.Version;

@Table(name = "Kunde_TB")
@Entity(name = "Kunde")
public class Kunde implements Serializable {
	
	@Id
	@GeneratedValue
	private int id;
	

	@Enumerated(EnumType.STRING)
	private Anrede anrede;
	
	@Column(name = "vor_name", length = 50)
	private String vorname;

	@Basic(fetch = FetchType.EAGER)
	@Column(name = "nach_name", length = 255)
	private String nachname;
	
	@Transient
	private String alter;
		
	@Embedded
	private Adresse adresse;
	
	
	@ElementCollection(fetch = FetchType.EAGER)
	private Set<Telefon> telefone;
	
	@Version
	private Long version;
	
	
	public Anrede getAnrede() {
		return anrede;
	}

	public void setAnrede(Anrede anrede) {
		this.anrede = anrede;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getAlter() {
		return alter;
	}

	public void setAlter(String alter) {
		this.alter = alter;
	}

	public Set<Telefon> getTelefone() {
		return telefone;
	}

	public void setTelefone(Set<Telefon> telefone) {
		this.telefone = telefone;
	}

	public int getId() {
		return id;
	}

	public Long getVersion() {
		return version;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	@Override
	public String toString() {
		return "Kunde [id=" + id + ", anrede=" + anrede + ", vorname=" + vorname + ", nachname=" + nachname + ", alter="
				+ alter + ", adresse=" + adresse + ", telefone=" + telefone + ", version=" + version + "]";
	}
	
	
}
