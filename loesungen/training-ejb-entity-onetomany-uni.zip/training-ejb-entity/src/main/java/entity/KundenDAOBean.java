package entity;

import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless
public class KundenDAOBean implements KundenDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public int erzeugeKunde(Anrede anrede, String vorname, String nachname) {
		Kunde kunde = new Kunde();
		kunde.setAnrede(anrede);
		kunde.setVorname(vorname);
		kunde.setNachname(nachname);
		
		entityManager.persist(kunde);
		
		return kunde.getId();
	}

	@Override
	public Kunde findeKunde(int id) {
		return entityManager.find(Kunde.class, id);
	}

	@Override
	public Kunde aktualisiereKunde(int id, String vorname, String nachname) {
		Kunde kunde = findeKunde(id);
		if (kunde != null) {
			kunde.setVorname(vorname);
			kunde.setNachname(nachname);
		}
		return kunde;
	}

	@Override
	public Kunde setzeAdresse(int kundenId, Adresse adresse) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.setAdresse(adresse);
		}
		return kunde;
	}

	@Override
	public Kunde telefonnumerHinzufuegen(int kundenId, Telefon telefon) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.getTelefone().add(telefon);
		}
		return kunde;
	}

	@Override
	public Kunde telefonnumerEntfernen(int kundenId, Telefon telefon) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.getTelefone().remove(telefon);
		}
		return kunde;
	}
	
	public Kunde wareHinzufuegen(int kundenId, Ware ware) {
		Kunde kunde = findeKunde(kundenId);
		if (kunde != null) {
			kunde.getWaren().add(ware);
		}
		return kunde;
		
	}

}
